#include <stdio.h>
#include "Mod.h"

int main(int argc, char* argv[])
{
	int a = 18, b = 24, c;
	c = nod(a, b);
	printf("nod=%d\n", c);
	return 0;
}
