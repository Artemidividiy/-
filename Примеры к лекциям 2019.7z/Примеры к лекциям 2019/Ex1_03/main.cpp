#include <iostream>
using namespace std;

int main()
{
	int i, s;
	for (i = 1, s = 0; i <= 10; i++) s += i;
	cout << "Sum=" << s << endl;
	return 0;
}
