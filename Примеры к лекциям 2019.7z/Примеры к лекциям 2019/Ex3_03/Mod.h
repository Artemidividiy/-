#pragma once
int nod(int a, int b);