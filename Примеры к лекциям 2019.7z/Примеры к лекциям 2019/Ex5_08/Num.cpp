
void Show(TElement *e)
   { e->Print();}